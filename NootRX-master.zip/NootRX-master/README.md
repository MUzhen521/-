# NootRX ![GitHub Workflow Status](https://img.shields.io/github/actions/workflow/status/ChefKissInc/NootRX/main.yml?branch=master&logo=github&style=for-the-badge)

Lilu plug-in for unsupported RDNA 2 desktop dGPUs. Conflicts with WhateverGreen and NootedRed.

Currently supports:

- Navi 21, on macOS Big Sur and newer
- Navi 22, on macOS Monterey and newer (Yup)
- Navi 23, on macOS Monterey and newer

(No native cards)

Navi 24 support soon™

The NootRX project is licensed under the `Thou Shalt Not Profit License version 1.5`. See `LICENSE`
